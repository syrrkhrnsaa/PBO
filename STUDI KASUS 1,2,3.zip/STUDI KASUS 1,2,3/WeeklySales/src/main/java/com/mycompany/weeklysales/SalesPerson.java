/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.weeklysales;

/**
 *
 * @author syira
 */
public class SalesPerson implements Comparable{

	private String firstName, lastName;
	private int totalSales;
	
	public SalesPerson(String first, String last, int sales) {
		super();
		this.firstName = first;
		this.lastName = last;
		this.totalSales = sales;
	}
	
	public String toString() {
		return lastName + ", " + firstName + ": \t" + totalSales;
	}
	
	public boolean equals (Object other) {
		return (lastName.equals(((SalesPerson)other).getLastName())
				&& firstName.equals(((SalesPerson)other).getFirstName()));
	}
	
	public int compareTo(Object other) {
            SalesPerson otherPerson = (SalesPerson) other;

            // Compare by total sales
            int salesComparison = Integer.compare(otherPerson.totalSales, this.totalSales);

            if (salesComparison == 0) {
                // If sales are equal, compare by last name
                int lastNameComparison = this.lastName.compareTo(otherPerson.lastName);
                if (lastNameComparison == 0) {
                    // If last names are equal, compare by first name
                    return this.firstName.compareTo(otherPerson.firstName);
                } else {
                    return lastNameComparison;
                }
            } else {
                return salesComparison;
            }
        }

	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public int getSales() {
		return totalSales;
	}
}
