/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.firm;

/**
 *
 * @author syira
 */
public class Firm {

    public static void main(String[] args) {
        Staff personnel = new Staff();
        personnel.Payday();
    }
}
